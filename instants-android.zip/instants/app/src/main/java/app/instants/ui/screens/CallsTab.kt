package app.instants.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.CallEntry
import app.instants.data.CallType
import app.instants.data.MockStore
import app.instants.ui.components.Avatar
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette

@Composable
fun CallsTab(onCall: (String) -> Unit, bottomPadding: Dp) {
    var missedOnly by rememberSaveable { mutableStateOf(false) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val calls = MockStore.calls.filter { !missedOnly || it.type == CallType.Missed }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = top + 12.dp, bottom = bottomPadding),
    ) {
        item(key = "title") {
            Text(
                "Calls",
                color = Palette.TextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.padding(horizontal = 20.dp).staggerIn(0),
            )
        }
        item(key = "seg") {
            Box(Modifier.padding(horizontal = 20.dp, vertical = 14.dp).staggerIn(1)) {
                Segmented(missedOnly) { missedOnly = it }
            }
        }
        itemsIndexed(calls, key = { _, c -> c.id }) { index, call ->
            val row = Modifier.animateItem().let { if (index < 8) it.staggerIn(index + 2) else it }
            CallRow(call, row) { onCall(call.contactId) }
        }
    }
}

@Composable
private fun Segmented(missedOnly: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(
        targetValue = if (missedOnly) 88.dp else 0.dp,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
        label = "seg",
    )
    Box(
        Modifier
            .width(180.dp)
            .height(44.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Palette.Hairline, CircleShape)
            .padding(4.dp),
    ) {
        Box(
            Modifier.offset(x = x).size(84.dp, 36.dp).clip(CircleShape).background(Palette.Accent),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SegLabel("All", !missedOnly) { onChange(false) }
            SegLabel("Missed", missedOnly) { onChange(true) }
        }
    }
}

@Composable
private fun SegLabel(label: String, selected: Boolean, onClick: () -> Unit) {
    val fg by animateColorAsState(
        if (selected) Color.White else Color(0xFFC9CCD1), tween(250), label = "segFg",
    )
    Box(
        Modifier.size(84.dp, 36.dp).pressable(0.95f, haptic = true, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CallRow(call: CallEntry, modifier: Modifier, onCall: () -> Unit) {
    val contact = MockStore.contact(call.contactId)
    val (arrow, label) = when (call.type) {
        CallType.Outgoing -> "↗" to "Outgoing"
        CallType.Incoming -> "↙" to "Incoming"
        CallType.Missed -> "↙" to "Missed"
    }
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Avatar(contact.initials, 48.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                contact.name, color = Palette.TextPrimary, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                "$arrow $label · ${call.whenLabel}",
                color = if (call.type == CallType.Missed) Palette.AccentSoft else Palette.TextSecondary,
                fontSize = 14.sp,
            )
        }
        GlassIconButton(
            icon = Icons.Rounded.Call,
            description = "Call ${contact.name}",
            size = 44.dp,
            tint = Palette.AccentSoft,
            onClick = onCall,
        )
    }
}
