package app.instants.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Charcoal = Color(0xFF1B1C1F)
    val AvatarBg = Color(0xFF2C2E33)
    val TextPrimary = Color(0xFFF4F5F7)
    val TextSecondary = Color(0xFFA3A7AE)
    val Accent = Color(0xFF4A72B8)       // soft blue (sent bubbles, primary actions)
    val AccentSoft = Color(0xFF8FB3F0)   // light blue (icons, highlights)
    val BubbleIn = Color.White.copy(alpha = 0.10f)
    val Glass = Color.White.copy(alpha = 0.08f)
    val GlassBorder = Color.White.copy(alpha = 0.14f)
    val Hairline = Color.White.copy(alpha = 0.10f)
    val EndCall = Color(0xFFC95B5B)
}

@Composable
fun InstantsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Accent,
            background = Palette.Charcoal,
            surface = Palette.Charcoal,
            onBackground = Palette.TextPrimary,
            onSurface = Palette.TextPrimary,
        ),
        content = content,
    )
}
