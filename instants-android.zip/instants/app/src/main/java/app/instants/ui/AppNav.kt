package app.instants.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.instants.ui.screens.ChatScreen
import app.instants.ui.screens.InCallScreen
import app.instants.ui.screens.MainShell
import app.instants.ui.theme.Palette

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val ease = FastOutSlowInEasing

    NavHost(
        navController = nav,
        startDestination = "main", // registration screen comes later
        modifier = Modifier.fillMaxSize().background(Palette.Charcoal),
        enterTransition = { slideInHorizontally(tween(380, easing = ease)) { it / 3 } + fadeIn(tween(300)) },
        exitTransition = { slideOutHorizontally(tween(380, easing = ease)) { -it / 6 } + fadeOut(tween(250)) },
        popEnterTransition = { slideInHorizontally(tween(380, easing = ease)) { -it / 6 } + fadeIn(tween(300)) },
        popExitTransition = { slideOutHorizontally(tween(380, easing = ease)) { it / 3 } + fadeOut(tween(250)) },
    ) {
        composable("main") {
            MainShell(
                onOpenChat = { nav.navigate("chat/$it") },
                onCall = { nav.navigate("call/$it") },
            )
        }
        composable(
            route = "chat/{id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType }),
        ) { entry ->
            val id = entry.arguments?.getString("id") ?: return@composable
            ChatScreen(
                chatId = id,
                onBack = { nav.popBackStack() },
                onCall = { nav.navigate("call/$id") },
            )
        }
        composable(
            route = "call/{id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType }),
            enterTransition = { slideInVertically(tween(450, easing = ease)) { it / 6 } + fadeIn(tween(400)) },
            exitTransition = { fadeOut(tween(250)) },
            popEnterTransition = { fadeIn(tween(300)) },
            popExitTransition = { slideOutVertically(tween(350, easing = ease)) { it / 6 } + fadeOut(tween(300)) },
        ) { entry ->
            val id = entry.arguments?.getString("id") ?: return@composable
            InCallScreen(contactId = id, onEnd = { nav.popBackStack() })
        }
    }
}
