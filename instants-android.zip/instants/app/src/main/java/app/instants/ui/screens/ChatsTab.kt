package app.instants.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Contact
import app.instants.data.Message
import app.instants.data.MockStore
import app.instants.ui.components.Avatar
import app.instants.ui.components.GlassField
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette

@Composable
fun ChatsTab(onOpenChat: (String) -> Unit, bottomPadding: Dp) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(0) } // 0 all, 1 unread, 2 favorites, 3 groups
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    val chats = MockStore.chatOrder.filter { id ->
        val c = MockStore.contact(id)
        c.name.contains(query.trim(), ignoreCase = true) && when (filter) {
            1 -> (MockStore.unread[id] ?: 0) > 0
            2 -> c.favorite
            3 -> c.isGroup
            else -> true
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = top + 12.dp, bottom = bottomPadding),
    ) {
        item(key = "title") {
            Text(
                "Instants",
                color = Palette.TextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.padding(horizontal = 20.dp).staggerIn(0),
            )
        }
        item(key = "search") {
            Row(
                Modifier
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .fillMaxWidth()
                    .heightIn(min = 44.dp)
                    .staggerIn(1)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.07f))
                    .border(1.dp, Palette.Hairline, CircleShape)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Rounded.Search, null, tint = Palette.TextSecondary, modifier = Modifier.size(18.dp))
                GlassField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = "Search",
                    modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                    imeAction = ImeAction.Search,
                )
            }
        }
        item(key = "status") { StatusRow() }
        item(key = "chips") {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .staggerIn(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf("All", "Unread", "Favorites", "Groups").forEachIndexed { i, label ->
                    FilterPill(label, selected = filter == i) { filter = i }
                }
            }
        }
        if (chats.isEmpty()) {
            item(key = "empty") {
                Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                    Text("No chats found", color = Palette.TextSecondary, fontSize = 15.sp)
                }
            }
        }
        itemsIndexed(chats, key = { _, id -> id }) { index, id ->
            val contact = MockStore.contact(id)
            val last = MockStore.messages[id]?.lastOrNull()
            val rowModifier = Modifier.animateItem().let { if (index < 8) it.staggerIn(index + 4) else it }
            ChatRow(
                contact = contact,
                last = last,
                unread = MockStore.unread[id] ?: 0,
                modifier = rowModifier,
                onClick = { onOpenChat(id) },
            )
        }
    }
}

@Composable
private fun StatusRow() {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { StatusCard(label = "Add status", initials = null, index = 0) }
        itemsIndexed(MockStore.statuses) { i, id ->
            val c = MockStore.contact(id)
            StatusCard(label = c.name.substringBefore(" "), initials = c.initials, index = i + 1)
        }
    }
}

@Composable
private fun StatusCard(label: String, initials: String?, index: Int) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .size(88.dp, 124.dp)
            .staggerIn(index + 2, stepMs = 60)
            .pressable(0.95f, haptic = true) { }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Palette.Hairline, shape),
    ) {
        if (initials == null) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 30.dp).size(32.dp)
                    .clip(CircleShape).background(Palette.Accent),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        } else {
            Avatar(initials, 32.dp, Modifier.align(Alignment.TopStart).padding(8.dp), ring = true)
        }
        Text(
            label,
            color = Palette.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 8.dp, end = 8.dp, bottom = 10.dp),
        )
    }
}

@Composable
private fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) Palette.Accent else Color.White.copy(alpha = 0.05f), tween(250), label = "pillBg",
    )
    val fg by animateColorAsState(
        if (selected) Color.White else Color(0xFFC9CCD1), tween(250), label = "pillFg",
    )
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .heightIn(min = 36.dp)
            .pressable(0.94f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (selected) Palette.Accent else Palette.GlassBorder, shape)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ChatRow(
    contact: Contact,
    last: Message?,
    unread: Int,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val preview = when {
        last == null -> "Say hi"
        last.fromMe -> (if (last.read) "✓✓ " else "✓ ") + last.text
        else -> last.text
    }
    Row(
        modifier
            .fillMaxWidth()
            .pressable(0.985f, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Avatar(contact.initials, 48.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                contact.name, color = Palette.TextPrimary, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                preview, color = Palette.TextSecondary, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                last?.time ?: "",
                color = if (unread > 0) Palette.AccentSoft else Palette.TextSecondary,
                fontSize = 12.sp,
            )
            AnimatedVisibility(
                visible = unread > 0,
                enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(),
                exit = scaleOut() + fadeOut(),
            ) {
                Box(
                    Modifier.heightIn(min = 20.dp).widthIn(min = 20.dp)
                        .clip(CircleShape).background(Palette.Accent).padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("$unread", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
