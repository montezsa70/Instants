# Instants

Minimal, private messaging app for Android 15+ (Kotlin, Jetpack Compose). Charcoal background, soft blue accents and a frosted glass UI (real backdrop blur via Haze).

**Status:** UI prototype. All data is mocked in `data/MockData.kt` (chats, calls, replies). The registration screen is not built yet.

## Build the APK with GitHub Actions
1. Create a new GitHub repo and push this folder to the `main` branch.
2. Open the **Actions** tab, then run **Build APK** (it also runs on every push).
3. When it finishes, download the `instants-debug-apk` artifact, unzip it and install `app-debug.apk` on an Android 15+ device.

## Build locally
Needs JDK 17, the Android SDK (API 35) and Gradle 8.9+: `gradle assembleDebug`

## Structure
- `data/` mock store (swap for real repositories later)
- `ui/theme/` palette and theme
- `ui/components/` glass surface, press feedback, buttons, text field
- `ui/screens/` Chats, Calls, Settings, Chat, In-call, tab shell
- `ui/AppNav.kt` navigation and page transitions
